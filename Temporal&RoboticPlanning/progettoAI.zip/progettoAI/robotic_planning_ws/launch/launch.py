import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    example_dir = get_package_share_directory('robotic_planning_ws') # launch directory
    namespace = LaunchConfiguration('namespace')

    declare_namespace_cmd = DeclareLaunchArgument(
        'namespace',
        default_value='',
        description='Namespace')

    plansys2_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(
            get_package_share_directory('plansys2_bringup'),
            'launch',
            'plansys2_bringup_launch_monolithic.py')),
        launch_arguments={
          'model_file': example_dir + '/pddl/domain_extended.pddl',
          'namespace': namespace
          }.items())

    move_cmd = Node(
        package='robotic_planning_ws',
        executable='move',
        name='move',
        namespace=namespace,
        output='screen',
        parameters=[])

    fill_cmd = Node(
        package='robotic_planning_ws',
        executable='fill',
        name='fill',
        namespace=namespace,
        output='screen',
        parameters=[])

    load_cmd = Node(
        package='robotic_planning_ws',
        executable='load',
        name='load',
        namespace=namespace,
        output='screen',
        parameters=[])   
        
    unload_cmd = Node(
        package='robotic_planning_ws',
        executable='unload',
        name='unload',
        namespace=namespace,
        output='screen',
        parameters=[])     
        
    empty_cmd = Node(
        package='robotic_planning_ws',
        executable='empty',
        name='empty',
        namespace=namespace,
        output='screen',
        parameters=[])   
        
    emptyatleastone_cmd = Node(
        package='robotic_planning_ws',
        executable='emptyatleastone',
        name='emptyatleastone',
        namespace=namespace,
        output='screen',
        parameters=[])        
        
        
    ld = LaunchDescription()

    ld.add_action(declare_namespace_cmd)

    # Declare the launch options
    ld.add_action(plansys2_cmd)

    ld.add_action(move_cmd)
    ld.add_action(fill_cmd)
    ld.add_action(load_cmd)
    ld.add_action(unload_cmd)
    ld.add_action(empty_cmd)
    ld.add_action(emptyatleastone_cmd)

    return ld

