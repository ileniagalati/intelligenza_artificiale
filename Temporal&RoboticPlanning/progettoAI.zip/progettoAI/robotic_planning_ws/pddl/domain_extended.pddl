(define
 (domain temporal_emergency)
 (:requirements :strips :typing :durative-actions :fluents)

 (:types
  location - localizable
  carrierplace - localizable
  agent - localizable
  content - localizable
  box - localizable
  carrier - localizable
  person - localizable
 )

 (:functions
  (content_weight ?c - content)
  (box_weight ?b - box)
  (carrier_weight ?c - carrier)
  (fill_duration)
  (move_duration)
  (load_duration)
  (empty_duration)
 )

 (:predicates
  (at ?o - localizable ?l - location)
  (emptybox ?b - box)
  (inbox ?b - box ?c - content)
  (boxonplace ?b - box ?p - carrierplace)
  (carrierplace ?p - carrierplace ?c - carrier)
  (avaiableplace ?p - carrierplace)
  (has ?p - person ?c - content)
  (hassomething ?p - person)
  (need  ?p - person ?c - content)
  (needall ?p - person)
  (needsomething ?p - person)
  (freeagent ?g - agent)
 )
 
 (:durative-action fill
  :parameters (?a - agent ?b - box ?c - content ?l - location)
  :duration (= ?duration (* (content_weight ?c) (fill_duration)))
  :condition (and
   (at start (freeagent ?a))
   (at start (emptybox ?b))
   (over all (at ?a ?l))
   (over all (at ?b ?l))
   (over all( at ?c ?l))
  )
  :effect (and
   (at start (not (freeagent ?a)))
   (at start (not (emptybox ?b)))
   (at end (inbox ?b ?c))
   (at end (increase (box_weight ?b) (content_weight ?c)))
   (at end (freeagent ?a))
  )
 )

 (:durative-action move
  :parameters (?a - agent ?c - carrier ?from - location ?to - location)
  :duration (= ?duration (* (carrier_weight ?c) (move_duration)))
  :condition (and
   (at start (freeagent ?a))
   (at start (at ?a ?from))
   (at start (at ?c ?from))
  )
  :effect (and
   (at start (not (freeagent ?a)))
   (at start (not (at ?a ?from)))
   (at start (not (at ?c ?from)))
   (at end (at ?a ?to))
   (at end (at ?c ?to))
   (at end (freeagent ?a))
  )
 )

 (:durative-action empty
  :parameters (?a - agent ?b - box ?c - content ?p - person ?l - location)
  :duration (= ?duration (* (content_weight ?c) (empty_duration)))
  :condition (and
   (at start (freeagent ?a))
   (at start (inbox ?b ?c))
   (at start (need ?p ?c))
   (over all (at ?a ?l))
   (over all (at ?b ?l))
   (over all (at ?p ?l))
   (over all (needall ?p))
  )
  :effect (and
   (at start (not(freeagent ?a)))
   (at start (emptybox ?b))
   (at start (not (need ?p ?c)))
   (at end (not (inbox ?b ?c)))
   (at end (has ?p ?c))
   (at end (decrease (box_weight ?b) (content_weight ?c)))
   (at end (freeagent ?a))
  )
 )

 (:durative-action load
  :parameters (?a - agent ?c - carrier ?p - carrierplace ?b - box ?l - location)
  :duration (= ?duration (* (box_weight ?b) (load_duration)))
  :condition (and
   (at start (freeagent ?a))
   (over all (at ?a ?l))
   (over all (at ?b ?l))
   (over all (at ?c ?l))
   (over all (carrierplace ?p ?c))
   (at start (avaiableplace ?p))
  )
  :effect (and
   (at start (not (freeagent ?a)))
   (at start (not (avaiableplace ?p)))
   (at end (not (at ?b ?l)))
   (at end (boxonplace ?b ?p))
   (at end (increase (carrier_weight ?c) (box_weight ?b)))
   (at end (freeagent ?a))
  )
 )

 (:durative-action unload
  :parameters (?a - agent ?c - carrier ?p - carrierplace ?b - box ?l - location)
  :duration (= ?duration (* (box_weight ?b) (load_duration)))
  :condition (and
   (at start (freeagent ?a))
   (at start (boxonplace ?b ?p))
   (over all (at ?a ?l))
   (over all (at ?c ?l))
   (over all(carrierplace ?p ?c))
  )
  :effect (and
   (at start (not (freeagent ?a)))
   (at start (at ?b ?l))
   (at start (avaiableplace ?p))
   (at end (not (boxonplace ?b ?p)))
   (at end (decrease (carrier_weight ?c) (box_weight ?b)))
   (at end (freeagent ?a))
  )
 )

 (:durative-action emptyatleastone
  :parameters (?a - agent ?b - box ?c - content ?p - person ?l - location)
  :duration (= ?duration (* (content_weight ?c) (empty_duration)))
  :condition (and
   (at start (freeagent ?a))
   (at start (inbox ?b ?c))
   (at start (need ?p ?c))
   (over all (at ?a ?l))
   (over all (at ?b ?l))
   (over all (at ?p ?l))
   (over all (needsomething ?p))
  )
  :effect (and
   (at start (not (freeagent ?a)))
   (at start (emptybox ?b))
   (at start (not (need ?p ?c)))
   (at start (not (needsomething ?p)))
   (at end (not (inbox ?b ?c)))
   (at end (hassomething ?p))
   (at end (decrease (box_weight ?b) (content_weight ?c)))
   (at end (freeagent ?a))
  )
 )
 
)
